<?php
/* Smarty version 3.1.34-dev-7, created on 2019-01-17 01:36:01
  from '/var/www/html/doxbin.org/smarty/templates/default/raw.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5c403e718bfdb0_94630251',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c5056aef55d91fd21af7549d01b7ab74d1f331e2' => 
    array (
      0 => '/var/www/html/doxbin.org/smarty/templates/default/raw.tpl',
      1 => 1547714157,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c403e718bfdb0_94630251 (Smarty_Internal_Template $_smarty_tpl) {
?><pre><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['dox']->value['dox'], ENT_QUOTES, 'UTF-8', true);?>
</pre><?php }
}
