<?php
/* Smarty version 3.1.34-dev-7, created on 2019-01-17 09:23:54
  from '/var/www/html/doxbin.org/smarty/templates/default/tos.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5c40ac1a29eb31_89266889',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f446516c6e049b53e58f929bd3ead9881e9ebea0' => 
    array (
      0 => '/var/www/html/doxbin.org/smarty/templates/default/tos.tpl',
      1 => 1547742223,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c40ac1a29eb31_89266889 (Smarty_Internal_Template $_smarty_tpl) {
?>    <div class="container tos">
      <p>created by <a href="https://realsunjester.wordpress.com/">sunjester</a></p>
      <p>profiles @ <a href="https://runtime.rip/member.php?action=profile&uid=141">runtime.rip</a>, <a href="https://sinister.ly/User-sunjester">Sinister.ly</a>, <a href="https://hackforums.net/member.php?action=profile&uid=4051592">HackForums</a></p>
    </div>
<?php }
}
